#' method of class lad 
#' 
#' writes the named coefficients vector to the console 
#'
#' @param x      a lad object
#' @param ... further arguments passed to or from other methods
#' @return       the named coefficients vector
#' @export

print.lad<-function(x,...){
  cat("beta0","\t",x$coefficient[1],"\n")
  cat("beta1","\t",x$coefficient[2],"\n")
}

