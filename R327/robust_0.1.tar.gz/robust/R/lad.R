#' Least absolute deviations regression
#'
#' lad(x, y) takes arguments vectors x and y 
#' and returns an object having the (new) class "lad" 
#' and consisting of a list components.
#' 
#' @param x,y      variables for the regression
#' @return   \strong{coefficients}:  a vector of estimates
#' @return   \strong{fitted.values}: a vector of fitted value 
#' @return   \strong{residuals}:   a vector of residuals  
#' @export
#' @examples
#' a<-lad(x=area$land, y=area$farm)
#' print(a)
#' b<-lm(farm~land,data=area)
#' plot(area$land,area$farm)
#' abline(a,col="red",lty=1)
#' abline(b,col="blue",lty=2)
#' legend("topright",c("lad","lse"),col=c("red","blue"),lty=c(1,2))
#' 
#' predict(a,quantile(area$land,c(0,.25,.5,.75,1)))

lad <- function(x,y) {
  f1 = function(b){ # Define function Tukey = f(beta0, beta1).
    b1 <- b[1]#beta0
    b2 <- b[2]#beta1
    t<- y- b1 - b2*x
    robust<- sum(abs(t))
    return(robust)
  }
  grr <- function(b) { ## Gradient of 'f1'
    b1 <- b[1]
    b2 <- b[2]
    t<- y- b1 - b2*x
    grad <- c(sum(-sign(t)),
              sum(-sign(t)*x))
    
  return(grad)
  }
  initials<- lm(y~x)
  initials<-initials$coefficients
  betas<-optim(par = initials,fn = f1,grr, method ="Nelder-Mead")
  coefficient<-betas$par
  fitted<-cbind(1,x)%*%coefficient
  residuals<-y-fitted
  result<-list(coefficients=coefficient,fitted.values=fitted,residuals=residuals)
  class(result)<-"lad"
  return(result)
}

