#' method of class lad
#'
#' takes a lad object object and returns its vector of coefficients.
#' 
#' @param object      a lad object
#' @param ... further arguments passed to or from other methods
#' @return       the coefficients vector
#' @export

coef.lad<-function(object,...){
  return(object$coefficients)
}

