#'area is a data frame from farmLandArea,csv
#'
#' @format area is a data frame with 3 columns and 50 rows:
#'
#' @source
#' this data are from a csv file from \url{http://www.stat.wisc.edu/~jgillett/327-3/2/farmLandArea.csv}
#'
"area"