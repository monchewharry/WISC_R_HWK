#' method of class lad
#'
#' @param object      a lad object
#' @param new.x       a vector
#' @param ... further arguments passed to or from other methods
#' @return a vector containing lad’s predictions at the x values in new.x.
#' @export  
#' 

predict.lad<-function(object,new.x,...){
  cbind(1,new.x)%*%object$coefficients
}